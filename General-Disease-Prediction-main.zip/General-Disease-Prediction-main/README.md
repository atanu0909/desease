This is a ML project on General Disease Prediction
Using XGBoost Classifier to predict disease based on given set of symptoms
Used Joblib for serializing and unserializing the Classifier, LabelEncoder and the Dataset
